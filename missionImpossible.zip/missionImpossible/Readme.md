#Prerequisies
  Nodejs version 8+

#Run Application
   npm start --silent <inputfilepath>
  